function checklogin() {	
	const login = document.getElementById('loginbox');
	const login_email = document.getElementById('login_email');
	const login_password = document.getElementById('login_password');

	login.addEventListener('submit', e => {
	e.preventDefault();
	var x=0;
	const loginemailValue = login_email.value.trim();
	const loginpasswordValue = login_password.value.trim();
	
	if(loginemailValue === '') {
		document.getElementById('lemail').style.borderColor = "red";
		x=1;
		document.getElementById("error_lemail").style.display = "block";
	} 
	else if (!isEmail(loginemailValue)) {
		document.getElementById('lemail').style.borderColor = "red";
		x=1;
		document.getElementById("error_lemail").style.display = "block";
	}
	else{
		document.getElementById('lemail').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('lemail').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('lemail').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('lemail').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById("error_lemail").style.display = "none";
		
	}
	if(loginpasswordValue === '') {
		document.getElementById('lpass').style.borderColor = "red";
		x=1;
		document.getElementById("error_lpass").style.display = "block";
	} 
	else if (!ispass(loginpasswordValue)) {
		document.getElementById('lpass').style.borderColor = "red";
		x=1;
		document.getElementById("error_lpass").style.display = "block";
	}
	else{
		document.getElementById('lpass').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('lpass').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('lpass').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('lpass').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById("error_lpass").style.display = "none";
	}
	if(x==1){
		return false;
	}
	else{
	
		window.location.href = "file:///C:/Users/amann/OneDrive/Desktop/web lab/home.html";
	}
	});
	
}

function isEmail(login_email) {
	return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(login_email);
}
function ispass(login_password) {
	return /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/.test(login_password);
}
function isphone(phone) {
	return /^\d{10}$/.test(phone);
}


function forget() {
	
	const forget = document.getElementById('forgetpass');
	const forget_email = document.getElementById('forgetpassword_email');
	const forgetemailValue = forget_email.value.trim();
	
	if(forgetemailValue === '') {
		document.getElementById('femail').style.borderColor = "red";
		document.getElementById("error_femail").style.display = "block";
	} 
	else if (!isEmail(forgetemailValue)) {
		document.getElementById('femail').style.borderColor = "red";
		document.getElementById("error_femail").style.display = "block";
	}
	else{
		document.getElementById('femail').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('femail').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('femail').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('femail').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById('lpass').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('lpass').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('lpass').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('lpass').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById('lemail').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('lemail').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('lemail').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('lemail').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById("error_lemail").style.display = "none";
		document.getElementById("error_lpass").style.display = "none";
		document.getElementById("error_femail").style.display = "none";
		document.getElementById("forgetpass").style.display = "none";
		document.getElementById("loginbox").style.display = "none";
		document.getElementById("newuser").style.display = "none";
		document.getElementById("recov").style.display = "block";
		document.getElementById("reged").style.display = "none";
	}
	
}

function registration() {	
	const regestration = document.getElementById('newuser');
	const reg_email = document.getElementById('reg_email');
	const reg_password = document.getElementById('reg_pass');
	const reg_name = document.getElementById('reg_name');
	const reg_conf = document.getElementById('reg_conf');
	const reg_phone = document.getElementById('reg_phone');
	var y=0;

	const regemailValue = reg_email.value.trim();
	const regpasswordValue = reg_password.value.trim();
	const regnameValue = reg_name.value.trim();
	const regconfValue = reg_conf.value.trim();
	const regphoneValue = reg_phone.value.trim();
	
	if(regemailValue === '') {
		document.getElementById('reg_email').style.borderColor = "red";
		y=1;
		document.getElementById("error_remail").style.display = "block";
	} 
	else if (!isEmail(regemailValue)) {
		document.getElementById('reg_email').style.borderColor = "red";
		y=1;
		document.getElementById("error_remail").style.display = "block";
	}
	else{
		document.getElementById('reg_email').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('reg_email').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('reg_email').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('reg_email').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById("error_remail").style.display = "none";
	}
	if(regpasswordValue === '') {
		document.getElementById('reg_pass').style.borderColor = "red";
		y=1;
		document.getElementById("error_rpass").style.display = "block";
	} 
	else if (!ispass(regpasswordValue)) {
		document.getElementById('reg_pass').style.borderColor = "red";
		y=1;
		document.getElementById("error_rpass").style.display = "block";
	}
	else{
		document.getElementById('reg_pass').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('reg_pass').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('reg_pass').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('reg_pass').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById("error_rpass").style.display = "none";
	
	if(regpasswordValue != regconfValue) {
		document.getElementById('reg_conf').style.borderColor = "red";
		y=1;
		document.getElementById("error_rconf").style.display = "block";
	} 
	else{
		document.getElementById('reg_conf').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('reg_conf').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('reg_conf').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('reg_conf').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById("error_rconf").style.display = "none";
	}
	}
	if(regnameValue === '') {
		document.getElementById('reg_name').style.borderColor = "red";
		y=1;
		document.getElementById("error_rname").style.display = "block";
	} 
	else{
		document.getElementById('reg_name').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('reg_name').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('reg_name').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('reg_name').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById("error_rname").style.display = "none";
	}
	if (!isphone(regphoneValue)) {
		document.getElementById('reg_phone').style.borderColor = "red";
		y=1;
		document.getElementById("error_rphone").style.display = "block";
	}
	else{
		document.getElementById('reg_phone').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('reg_phone').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('reg_phone').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('reg_phone').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById("error_rphone").style.display = "none";
	}
	
	if(y==1){
		return false;
	}
	else{
		document.getElementById('femail').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('femail').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('femail').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('femail').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById('lpass').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('lpass').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('lpass').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('lpass').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById('lemail').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('lemail').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('lemail').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('lemail').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById('reg_phone').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('reg_phone').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('reg_phone').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('reg_phone').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById('reg_name').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('reg_name').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('reg_name').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('reg_name').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById('reg_conf').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('reg_conf').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('reg_conf').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('reg_conf').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById('reg_pass').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('reg_pass').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('reg_pass').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('reg_pass').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById("error_rpass").style.display = "none";
		document.getElementById('reg_email').style.borderBottomColor = "rgba(76,175,80,1)";
		document.getElementById('reg_email').style.borderTopColor = "rgba(76,175,80,0)";
		document.getElementById('reg_email').style.borderLeftColor = "rgba(76,175,80,0)";
		document.getElementById('reg_email').style.borderRightColor = "rgba(76,175,80,0)";
		document.getElementById("error_remail").style.display = "none";
		document.getElementById("error_rconf").style.display = "none";
		document.getElementById("error_rname").style.display = "none";
		document.getElementById("error_rphone").style.display = "none";
		document.getElementById("error_lemail").style.display = "none";
		document.getElementById("error_lpass").style.display = "none";
		document.getElementById("error_femail").style.display = "none";
		document.getElementById("forgetpass").style.display = "none";
		document.getElementById("loginbox").style.display = "none";
		document.getElementById("newuser").style.display = "none";
		document.getElementById("recov").style.display = "none";
		document.getElementById("reged").style.display = "block";
		
	}
	
	
}
